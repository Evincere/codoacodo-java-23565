package infrastructure.persistence.memory;

import java.util.ArrayList;

import infrastructure.persistence.IPersistencia;
import modelos.Usuario;

public class MemoryRepositoryImpl implements IPersistencia {
	
	public static ArrayList<Usuario> bdMemoria = new ArrayList<>();
	
	@Override
	public void guardar(Usuario newUsuario) {
		if(MemoryRepositoryImpl.bdMemoria.add(newUsuario)) {
			System.out.println("usuario " + newUsuario.getApellido()+ " fue grabado exitosamente con el id : " + newUsuario.getId() + ", idUUID: " + newUsuario.getIdUsuario());
		}
		
	}

	@Override
	public ArrayList<Usuario> listarUsuarios() {
		
		return MemoryRepositoryImpl.bdMemoria;
	}

	@Override
	public Usuario getUsuarioPorId(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario upadate(String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		
	}

}
